*) Put the H5 calibration files in the Default Files folder
*) Double click on run_prompt.bat to open a shell
*) Type `python make_configuration_4pi.py --help` and hit enter
   A list of available options will be printed on the console
   Choose your preferred options
*) Type `python make_configuration_4pi.py ` followed by your preferred options without `--help` and hit enter
*) Test the modes by running `python test_configuration.py`


examples: 
python make_conifuration_single.py --min 4 --max 22 -exclude "1,2,3"